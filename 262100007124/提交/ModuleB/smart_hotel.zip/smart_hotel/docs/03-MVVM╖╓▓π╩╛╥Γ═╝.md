﻿# MVVM 分层示意图（以 light 模块为例）

> 版本：v1.2.0 · 2026-10-20
> 选型说明：light 模块同时包含“总开关 / 场景 / 单灯”，能完整体现 View ↔ ViewModel ↔ Model 的协作与数据流向。
> 物理形态：`LightPage`、`LightViewModel`、`LightModel` 位于独立 HAR `features/light`（包名 `@smart_hotel/light`）；`AppState` 位于 `@smart_hotel/datastore`；`ApiService`/`HttpClient` 位于 `@smart_hotel/network`；`ToggleSwitch` 位于 `@smart_hotel/uicomponents`。

## 1. 分层关系

```mermaid
flowchart LR
  subgraph V["View 层 · LightPage（@ComponentV2）"]
    V1["UI 渲染<br/>总开关 / 场景 / 单灯"]
    V2["用户事件<br/>onClick → vm.xxx()"]
    V3["@Local vm<br/>读取 @Trace 字段"]
  end

  subgraph VM["ViewModel 层 · LightViewModel（@ObservedV2）"]
    VM1["@Trace 状态<br/>（通过 app 读取/写回）"]
    VM2["业务编排<br/>门控 / Toast / 状态写回"]
    VM3["调用 Model<br/>await LightModel.xxx()"]
  end

  subgraph M["Model 层 · LightModel + Commons"]
    M1["LightModel<br/>setMaster / setScene / toggleLight"]
    M2["ApiService<br/>REST 接口封装"]
    M3["HttpClient<br/>Bearer / 业务码 / 异常"]
    M4["AppState（@ObservedV2/@Trace）<br/>masterLight / activeSceneId / lights / logs"]
  end

  V1 -- "读取 @Trace（自动订阅）" --> VM1
  V2 -- "方法调用" --> VM2
  VM1 -- "状态变化触发刷新" --> V3
  VM2 -- "写回状态" --> M4
  VM3 --> M1
  M1 --> M2
  M2 --> M3
  M3 -- "响应 DTO" --> VM3
```

## 2. 类与成员

```mermaid
classDiagram
  class LightPage {
    -AppState app
    -LightViewModel vm
    +build()
    -sceneRes(icon) Resource
    -lightRes(id) Resource
    -sceneItem(scene) void
    -lightItem(item) void
  }

  class LightViewModel {
    +AppState app
    +toggleMaster() Promise~void~
    +tapScene(id, name) Promise~void~
    +toggleLight(item, on) Promise~void~
  }

  class LightModel {
    +setMaster(on) Promise~LightBatchResult~
    +setScene(sceneId) Promise~LightBatchResult~
    +toggleLight(id, on) Promise~LightOpResult~
  }

  class AppState {
    +boolean masterLight
    +string activeSceneId
    +LightItem[] lights
    +string[] logs
    +applyLightBatch(activeSceneId, masterLight, lights) void
    +addLog(text) void
  }

  LightPage --> LightViewModel : 持有 @Local
  LightViewModel --> LightModel : 调用
  LightViewModel --> AppState : 读写 @Trace
  LightPage --> AppState : 读取 @Trace
  LightModel --> ApiService : 委托
```

## 3. 典型数据流：点击“阅读”场景

```mermaid
sequenceDiagram
  autonumber
  participant U as 用户
  participant V as LightPage（View）
  participant VM as LightViewModel
  participant M as LightModel
  participant API as ApiService / HttpClient
  participant S as Mock 服务端
  participant ST as AppState

  U->>V: 点击“阅读”场景
  V->>VM: tapScene('reading', '阅读')
  alt 总开关未打开
    VM-->>U: Toast「请先打开总开关」
  else 总开关已打开
    VM->>M: setScene('reading')
    M->>API: POST /api/light/scene
    API->>S: Bearer Token + { sceneId }
    S-->>API: { code:0, data:{ activeSceneId, masterLight, lights } }
    API-->>M: LightBatchResult
    M-->>VM: LightBatchResult
    VM->>ST: applyLightBatch(...)
    ST-->>V: @Trace 变化
    V-->>U: 场景卡片高亮 + 灯具开关刷新 + Toast「切换为阅读」
  end
```

## 4. 三层职责与约束

| 层 | 职责 | 允许 | 禁止 |
| --- | --- | --- | --- |
| View | 布局、样式、动画、事件转发 | 读 ViewModel/AppState 的 `@Trace` 字段；调用 VM 方法 | 直接调用 `ApiService` / `HttpClient`；直接改 Model |
| ViewModel | 业务编排、门控、Toast、状态写回 | 调用 Model；读写 AppState；调用 UI 提示 API | 直接操作组件/节点；包含布局代码 |
| Model | 接口调用与 DTO 转换 | 调用 `ApiService` | 包含 UI 状态与 Toast；直接读写 AppState |

## 5. ArkUI V2 绑定说明

| 场景 | 用法 | 说明 |
| --- | --- | --- |
| 组件声明 | `@ComponentV2` | 全部页面/组件均使用 V2 |
| 页面局部状态 | `@Local vm: LightViewModel` | ViewModel 实例由 View 持有 |
| 跨页共享状态 | `@ObservedV2 class AppState` + `@Trace` 字段 | 单例注入，字段变化自动刷新读取方 |
| 父传子 | `@Param`（如 `TabBar.active`、`ToggleSwitch.checked`） | 单向输入 |
| 子传父 | `@Event`（如 `TabBar.onSelect`、`LoginPage.onLoggedIn`） | 回调 |
| 深度监听 | 无需 `@Watch` | 窗帘进度由 ViewModel 的 `@Trace` 驱动；轮询更新共享状态后，通过 `AppState` 的窗帘监听回调同步到 ViewModel（避免跨 HAR 的 `@Monitor` 路径校验限制） |

**双向绑定链路**：View 读取 `vm`/`app` 的 `@Trace` 字段（VM → View）；用户事件调用 `vm.xxx()`（View → VM）；VM 通过 Model 请求服务端并将结果写回 `AppState`，再次驱动 View 刷新。

## 6. 物理模块与依赖

| 层 | 物理模块 | 包名 | 依赖 |
| --- | --- | --- | --- |
| View + ViewModel + Model | `features/light` | `@smart_hotel/light` | `datastore`、`network`、`utils`、`uicomponents` |
| 共享状态 / 仓库 | `commons/datastore` | `@smart_hotel/datastore` | `network`、`utils` |
| 网络 / DTO | `commons/network` | `@smart_hotel/network` | 无内部依赖 |
| 公共组件 | `commons/uicomponents` | `@smart_hotel/uicomponents` | `utils` |
| 纯规则 / 主题 / 缩放 | `commons/utils` | `@smart_hotel/utils` | 无内部依赖 |
| 产品壳 | `products/phone`（HAP） | `phone` | 5 个 Feature + 4 个 Commons |

跨模块 import 统一走包名与 HAR 根 `Index.ets`，例如：

```ts
import { AppState, RoomRepository } from '@smart_hotel/datastore';
import { ApiError, LightBatchResult, LightItem } from '@smart_hotel/network';
import { BusinessRules, AppColor, u } from '@smart_hotel/utils';
import { ToggleSwitch } from '@smart_hotel/uicomponents';
```

## 7. 其他 Feature 的对应关系

| Feature | View | ViewModel 关键方法 | Model 关键方法 |
| --- | --- | --- | --- |
| login | `LoginPage` | `loadCredential` / `submit` | `LoginModel.login` |
| home | `HomePage` | `toggleAcPower` / `stepTemp` / `tapScene` / `tapGoodnight` / `tapService` | `HomeModel.setAcPower` / `setTemperature` / `toggleService`（场景仅本地高亮） |
| curtain | `CurtainPage` | `control` / `batch` / `leftX` / `rightX` / `statusOf` | `CurtainModel.control` / `batch` |
| service | `ServicePage` | `toggleService` / `triggerSos` / `doLogout` | `ServiceModel.toggle` / `sos` / `logout` |


